# inventory logic
